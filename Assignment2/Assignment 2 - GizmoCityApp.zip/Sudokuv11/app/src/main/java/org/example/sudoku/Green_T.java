package org.example.sudoku;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

/**
 * Created by D on 7/16/2015.
 */
public class Green_T extends Activity {


    TextView textField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.green_t_first_hint);
        textField=(TextView)findViewById(R.id.countdown_timer);

        new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
                textField.setText("seconds remaining: " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                textField.setText("done!");
            }
        }.start();

    }
}
