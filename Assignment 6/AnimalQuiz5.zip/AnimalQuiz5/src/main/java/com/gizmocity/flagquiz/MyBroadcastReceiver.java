package com.gizmocity.flagquiz;

/**
 * Created by JJJJ on 7/17/2015.
 */
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyBroadcastReceiver extends BroadcastReceiver
{
    @Override
    public void onReceive(Context context, Intent intent)
    {

        if (intent.getAction().equals("com.gizmocity.flagquiz"))
        {
            Intent i = new Intent(context, com.gizmocity.flagquiz.MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        }
    }
}
