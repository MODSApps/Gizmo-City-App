/***
 * Excerpted from "Hello, Android",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material, 
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose. 
 * Visit http://www.pragmaticprogrammer.com/titles/eband3 for more book information.
 ***/
package org.example.gizmoCity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

import org.example.gizmoCity.R;

import org.example.gizmoCity.AnimalSounds;
import org.example.gizmoCity.Kaleidoscope;
import org.example.gizmoCity.MegaMicAndSpeaker;
import org.example.gizmoCity.Piano;
import org.example.gizmoCity.Sudoku;

public class Waves extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.waves);
    }

    public void clickHome(final View view)
    {
        startActivity(new Intent(this, Sudoku.class));
    }

    public void clickAnimalSounds(final View view)
    {
        startActivity(new Intent(this, AnimalSounds.class));
    }

    public void clickKaleidoscope(final View view)
    {
        startActivity(new Intent(this, Kaleidoscope.class));
    }

    public void clickMegaMicAndSpeaker(final View view)
    {
        startActivity(new Intent(this, MegaMicAndSpeaker.class));
    }

    public void clickPiano(final View view)

    {
        startActivity(new Intent(this, Piano.class));
    }

    public void  clickAnimalGame(final View view)
    {

    }

}
