package org.example.gizmoCity;

/**
 * Created by D on 7/13/2015.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import org.example.gizmoCity.R;

public class Puzzles extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.puzzles);
    }

    public void clickGreenTandSixTriangles(final View view)
    {
        startActivity(new Intent(this, GreenTandSixTriangles.class));
    }


    public void clickHome(final View view)
    {
        startActivity(new Intent(this, Sudoku.class));
    }
}

