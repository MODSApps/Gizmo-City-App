package org.example.gizmoCity;

/**
 * Created by D on 7/13/2015.
 */

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;

public class GreenTFirstHint extends Activity {

    private static final String TAG = "Sudoku";
    Context context;
    private TextView secondsToHint1;
    private TextView secondsToHint2;
    private TextView secondsToSolution;
    Chronometer countTotalTime;
    TextView displayTotalTime;
    View hint1Button;
    View hint2Button;
    View solutionButton;
    ImageView hint1Img;
    ImageView hint2Img;
    ImageView solutionImg;
    private boolean running;

    //TextView mTextField=(TextView)findViewById(R.id.countdown_timer);
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.green_t_first_hint);

        //begin count total time
        displayTotalTime = (TextView) findViewById(R.id.displayYourTotalTime);
        displayTotalTime.setText("Your total time: ");
        countTotalTime = (Chronometer) findViewById(R.id.displayChronometer);
        countTotalTime.start();

        //code for timer
        context = getApplicationContext();
        secondsToHint1 = (TextView) this.findViewById(R.id.displayTimer);
        secondsToHint2 = (TextView) this.findViewById(R.id.displayTimer2);
        secondsToSolution = (TextView) this.findViewById(R.id.displayTimer);
        hint1Button = (ImageButton) findViewById(R.id.hint_button);
        hint2Button = (ImageButton) findViewById(R.id.hint_button2);
        solutionButton = (ImageButton) findViewById(R.id.solution_button);
        hint1Img = (ImageView) findViewById(R.id.hint1);
        hint2Img = (ImageView) findViewById(R.id.hint2);
        solutionImg = (ImageView) findViewById(R.id.solution);

        //set initial visibilities
        secondsToHint2.setVisibility(View.INVISIBLE);
        hint2Button.setVisibility(View.INVISIBLE);
        hint2Img.setVisibility(View.INVISIBLE);
        secondsToSolution.setVisibility(View.INVISIBLE);
        solutionButton.setVisibility(View.INVISIBLE);
        solutionImg.setVisibility(View.INVISIBLE);


        //show time left until next hint is available
        if(!running)        //if timer is running/on
        {
            new CountDownTimer(10000, 1000)
            {
                public void onTick(long millisUntilFinished)
                {
                    secondsToHint1.setVisibility(View.VISIBLE);
                    hint1Button.setVisibility(View.INVISIBLE);
                    secondsToHint1.setText("Seconds until next hint available\n" +
                            "                           " + millisUntilFinished / 1000);
                    running = true;
                }

                public void onFinish()
                {
                    secondsToHint1.setText("");
                    hint1Button.setVisibility(View.VISIBLE);
                }
            }.start();
        }
    }

    public void clickHint1Button(final View view)
    {
        hint1Img.setVisibility(View.VISIBLE);
        hint1Img.getLayoutParams().height = 800;
        hint1Img.requestLayout();
        hint1Button.setVisibility(View.INVISIBLE);

        new CountDownTimer(10000, 1000)
        {
            public void onTick(long millisUntilFinished)
            {
                secondsToHint2.setVisibility(View.VISIBLE);
                secondsToHint2.setText("Seconds until next hint available\n" +
                        "                           " + millisUntilFinished / 1000);
                running = true;
            }

            public void onFinish()
            {
                secondsToHint2.setText("");
                hint2Button.setVisibility(View.VISIBLE);
            }
        }.start();
    }

    public void clickHint2Button(final View view)
    {
        hint2Img.setVisibility(View.VISIBLE);
        hint2Img.getLayoutParams().height = 800;
        hint2Img.requestLayout();
        hint2Button.setVisibility(View.INVISIBLE);

        new CountDownTimer(10000, 1000)
        {
            public void onTick(long millisUntilFinished)
            {
                secondsToSolution.setVisibility(View.VISIBLE);
                secondsToSolution.setText("Seconds until solution is available\n" +
                        "                           " + millisUntilFinished / 1000);
                running = true;
            }

            public void onFinish()
            {
                secondsToSolution.setText("");
                solutionButton.setVisibility(View.VISIBLE);
            }
        }.start();
    }

    public void clickSolutionButton(final View view)
    {
        solutionImg.setVisibility(View.VISIBLE);
        solutionImg.getLayoutParams().height = 800;
        solutionImg.requestLayout();
        solutionButton.setVisibility(View.INVISIBLE);
        //hint3Button.setVisibility(View.INVISIBLE);
    }

    /*public void clickAbout(final View view)
    {
        startActivity(new Intent(this, InformationActivity.class));
    }*/

    public void clickHome(final View view)
    {
        startActivity(new Intent(this, Sudoku.class));
    }

    /*public void clickMap(final View view)
    {
        Intent intent = new Intent();
        intent.setAction("com.example.modsexplorer");
        sendBroadcast(intent);
    }*/
}