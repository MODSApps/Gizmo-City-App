package org.example.gizmoCity;

/**
 * Created by D on 7/13/2015.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import org.example.gizmoCity.R;

public class GreenT extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.green_t);
    }


    public void clickGreenTStart(final View view)
    {
        startActivity(new Intent(this, GreenTFirstHint.class));
    }

}

