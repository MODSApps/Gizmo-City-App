package org.example.gizmoCity;

/**
 * Created by D on 7/13/2015.
 */

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

import org.example.gizmoCity.R;

public class Kaleidoscope extends Activity {
    ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kaleidoscope);
    }

    public void clickAnimalGame(final View v)
    {

    }

    public void clickHome(final View view)
    {
        startActivity(new Intent(this, Sudoku.class));
    }

}

