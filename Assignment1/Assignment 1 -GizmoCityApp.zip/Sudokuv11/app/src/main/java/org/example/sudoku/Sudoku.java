/***
 * Excerpted from "Hello, Android",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material, 
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose. 
 * Visit http://www.pragmaticprogrammer.com/titles/eband3 for more book information.
 ***/
package org.example.sudoku;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

public class Sudoku extends Activity implements OnClickListener {
    private static final String TAG = "Sudoku";

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // Set up click listeners for all the buttons
        View puzzles_Button = findViewById(R.id.puzzles_button);
        puzzles_Button.setOnClickListener(this);
        View physics_Button = findViewById(R.id.physics_button);
        physics_Button.setOnClickListener(this);
        View technology_Button = findViewById(R.id.technology_button);
        technology_Button.setOnClickListener(this);
        View back_Button = findViewById(R.id.back_button);
        back_Button.setOnClickListener(this);
        View recent_Button = findViewById(R.id.recent_button);
        recent_Button.setOnClickListener(this);
        View home_Button = findViewById(R.id.home_button);
        home_Button.setOnClickListener(this);
        View map_Button = findViewById(R.id.map_button);
        map_Button.setOnClickListener(this);
        View settings_Button = findViewById(R.id.settings_button);
        settings_Button.setOnClickListener(this);

        View continueButton = findViewById(R.id.sounds_and_visual_waves_button);
        continueButton.setOnClickListener(this);
    }

    // ...

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.puzzles_button:
                Log.d(TAG, "clicked on Puzzles");
                break;
            // More buttons go here (if any) ...
            case R.id.sounds_and_visual_waves_button:
                Log.d(TAG, "clicked on Sounds and Visual Waves");
                startActivity(new Intent(this, Waves.class));
                break;
            case R.id.physics_button:
                Log.d (TAG, "clicked on Physics");
                break;
            case R.id.technology_button:
                Log.d (TAG, "clicked on Technology");
                break;
            case R.id.back_button:
                Log.d (TAG, "clicked on Back");
                break;
            case R.id.recent_button:
                Log.d (TAG, "clicked on Recent");
                break;
            case R.id.home_button:
                Log.d (TAG, "clicked on Home");
                break;
            case R.id.map_button:
                Log.d (TAG, "clicked on Map");
                break;
            case R.id.settings_button:
                Log.d (TAG, "clicked on Settings");
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.settings:
                startActivity(new Intent(this, Prefs.class));
                return true;
            // More items go here (if any) ...
        }
        return false;
    }

    /** Ask the user what difficulty level they want */
    private void openNewGameDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.new_game_title)
                .setItems(R.array.difficulty,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialoginterface,
                                                int i) {
                                startGame(i);
                            }
                        })
                .show();
    }

    /** Start a new game with the given difficulty level */
    private void startGame(int i) {
        Log.d(TAG, "clicked on " + i);
        // Start game here...
    }
}
